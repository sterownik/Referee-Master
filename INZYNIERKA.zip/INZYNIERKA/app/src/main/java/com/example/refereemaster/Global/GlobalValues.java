package com.example.refereemaster.Global;

public class GlobalValues {


    public static boolean dzwiek;


    public static boolean wibracje;



}
