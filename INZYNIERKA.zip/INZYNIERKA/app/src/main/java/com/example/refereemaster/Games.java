package com.example.refereemaster;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class Games extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_games);
        getSupportActionBar().hide();
        ProgressBar exp = (ProgressBar)findViewById(R.id.exp);
        exp.setMax(100);
        exp.setProgress(50);
        exp.setScaleY(6f);
        TextView progressexp = (TextView)findViewById(R.id.progressexp);
        progressexp.setText(exp.getProgress()+"/"+exp.getMax());
        LinearLayout pierwszagra = (LinearLayout)findViewById(R.id.pierwszagra);
        pierwszagra.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),RegulaminowyMistrz.class);
                startActivity(intent);
            }
        });
    }
}
