package com.example.refereemaster;

import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.support.annotation.DrawableRes;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class RegulaminowyMistrz extends AppCompatActivity {
    RelativeLayout simple;
    TextView pytanie;
    String zaznaczona;
    Button odp1,odp2,odp3,odp4;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_regulaminowy_mistrz);
        getSupportActionBar().hide();
        try {
            Play();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    public void Play() throws IOException {
        simple = (RelativeLayout)findViewById(R.id.cala_gra);
        pytanie = (TextView)findViewById(R.id.pytanie);
        odp1 = (Button)findViewById(R.id.odp1);
        odp2 = (Button)findViewById(R.id.odp2);
        odp3 = (Button)findViewById(R.id.odp3);
        odp4 = (Button)findViewById(R.id.odp4);
        StringBuffer buf1 = new StringBuffer();
        String str = "";
        InputStream is = this.getResources().openRawResource(R.raw.pytania);
        Charset ch = Charset.forName("windows-1250");
        BufferedReader reader = new BufferedReader(new InputStreamReader(is,ch));
        if(is!=null)
        {
            while (( str = reader.readLine()) != null)
            {
                buf1.append(str + "\n");
            }
        }
        final String[] str2;
        is.close();
        String pytanko = buf1.toString();
        final String[] pytanieV = pytanko.split("#");
        final Random rand = new Random();

        int random = rand.nextInt(pytanieV.length-1);
       // Toast.makeText(getApplicationContext(),Integer.toString(pytanieV.length-1),Toast.LENGTH_LONG).show();

        str2 = pytanieV[random].split("&");
        str2[0] = str2[0].replaceAll("(?m)^\\s*$[\n\r]{1,}", "");
        str2[1] = str2[1].replaceAll("(?m)^\\s*$[\n\r]{1,}", "");
        str2[2] = str2[2].replaceAll("(?m)^\\s*$[\n\r]{1,}", "");
        str2[3] = str2[3].replaceAll("(?m)^\\s*$[\n\r]{1,}", "");
        str2[4] = str2[4].replaceAll("(?m)^\\s*$[\n\r]{1,}", "");
        pytanie.setText(str2[0]);

        int[] liczby = {1,2,3,4};
        ArrayList<Integer> lista = new ArrayList<Integer>();
        Random rand2= new Random();
        while (lista.size()<4)
        {
            int random2 = rand2.nextInt(liczby.length);
            if(!lista.contains(liczby[random2]))
            {
                lista.add(liczby[random2]);
            }
        }

        odp1.setText(str2[lista.get(0)]);
        odp2.setText(str2[lista.get(1)]);
        odp3.setText(str2[lista.get(2)]);
        odp4.setText(str2[lista.get(3)]);
        odblokuj();
        odp1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                zaznaczona = str2[0].replace("___",odp1.getText());
                pytanie.setText(zaznaczona);
                kolruj(odp1);
                zablokuj();
            }
        });
        odp2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                zaznaczona = str2[0].replace("___",odp2.getText());
                pytanie.setText(zaznaczona);
                kolruj(odp2);
                zablokuj();
            }
        });
        odp3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                zaznaczona = str2[0].replace("___",odp3.getText());
                pytanie.setText(zaznaczona);
                kolruj(odp3);
                zablokuj();
            }
        });
        odp4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                zaznaczona = str2[0].replace("___",odp4.getText());
                pytanie.setText(zaznaczona);
                kolruj(odp4);
               zablokuj();
            }
        });

    }
    public void zablokuj()
    {
            odp1.setEnabled(false);
            odp2.setEnabled(false);
            odp3.setEnabled(false);
            odp4.setEnabled(false);
    }
    public void kolruj(Button button)
    {
        Drawable image=(Drawable)getResources().getDrawable(R.drawable.rectangle2);
        button.setBackground(image);
    }
    public void odblokuj()
    {
        odp1.setEnabled(true);
        odp2.setEnabled(true);
        odp3.setEnabled(true);
        odp4.setEnabled(true);
    }

}
