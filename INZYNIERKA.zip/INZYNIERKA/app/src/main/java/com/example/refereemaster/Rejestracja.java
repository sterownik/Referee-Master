package com.example.refereemaster;

import android.app.ProgressDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

import androidx.annotation.NonNull;

public class Rejestracja extends AppCompatActivity {
   private EditText mail;
    private  EditText pass;
    private ProgressDialog progressDialog;
    private FirebaseAuth firebaseAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rejestracja);
        progressDialog = new ProgressDialog(this);
        firebaseAuth = FirebaseAuth.getInstance();




         mail = (EditText)findViewById(R.id.mail);
        pass = (EditText)findViewById(R.id.pass);
        Button register = (Button)findViewById(R.id.register);
        TextView textView = (TextView)findViewById(R.id.text);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registerUser();
            }
        });
    }
    private void registerUser()
    {
        String email = mail.getText().toString().trim();
        String password = pass.getText().toString().trim();

        if(TextUtils.isEmpty(email))
        {
            //e mail empty
            Toast.makeText(this,"E-mail nie może być pusty",Toast.LENGTH_LONG).show();
            return;
        }
        if(TextUtils.isEmpty(password))
        {
            //pass empty
            Toast.makeText(this,"Hasło nie może być puste",Toast.LENGTH_LONG).show();
            return;
        }
        //if validations are ok
        progressDialog.setMessage("Rejestrowanie użytkownika...");
        progressDialog.show();
        firebaseAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful())
                {
                    Toast.makeText(Rejestracja.this,"Jesteś zarejestrowany",Toast.LENGTH_LONG).show();
                }
                else
                {
                    Toast.makeText(Rejestracja.this,"Nie zostałeś zarejestrowany",Toast.LENGTH_LONG).show();
                }
            }
        });


    }

}
