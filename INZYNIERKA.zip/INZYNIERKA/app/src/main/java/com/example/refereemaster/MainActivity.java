package com.example.refereemaster;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import com.example.refereemaster.Global.GlobalValues;

import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;



import static java.security.AccessController.getContext;

public class MainActivity extends AppCompatActivity {
    final Context context = this;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_main);
        ImageView ustawienia = (ImageView)findViewById(R.id.ustawienia);
        Button login = (Button)findViewById(R.id.przycisklogowania);
        TextView bezKonta = (TextView)findViewById(R.id.bezkonta);
        ustawienia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showSettings();
            }
        });
        if(GlobalValues.dzwiek==true)
        {
            Toast.makeText(getApplicationContext(),"Wlaczono dzwiek",Toast.LENGTH_LONG);
        }
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),Games.class);
                startActivity(intent);
            }
        });
        bezKonta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),Rejestracja.class);
                startActivity(intent);
            }
        });
    }
    private void showSettings()
    {
        final Dialog dialog = new Dialog(context);
        dialog.setContentView(R.layout.settings);
        dialog.setTitle("Title...");
        CheckBox dzwiek = (CheckBox) dialog.findViewById(R.id.dzwiek);
        CheckBox wibracje = (CheckBox) dialog.findViewById(R.id.wibracje);
        dialog.show();

    }


}
